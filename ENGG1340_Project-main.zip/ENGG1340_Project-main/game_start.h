#ifndef GAME_START
#define GAME_START

void start(std::string &name, std::string &avatar);

#endif