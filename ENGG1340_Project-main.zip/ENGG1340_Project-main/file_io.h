#ifndef FILE_IO
#define FILE_IO

int in_data(std::string &name, std::string &avatar, int &boss_stage);
int out_data(std::string &name, std::string &avatar, int &boss_stage);

#endif