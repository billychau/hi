// process.h

#ifndef PROCESS
#define PROCESS

struct Statistic {
    int attack;
    int defence;
    int hp;
};

int process(Statistic *stat);

#endif
