// "file_io.cpp"

#include <iostream>
#include <string>
#include "file_io.h"

using namespace std;

int in_data(std::string &name, std::string &avatar, int &boss_stage){
    return 0;
}
int out_data(std::string &name, std::string &avatar, int &boss_stage){
    return 0;
}