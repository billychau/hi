// boss.h

#ifndef BOSS
#define BOSS

bool boss(std::string avatar, int &boss_stage);

#endif