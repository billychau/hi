// "printLeaderBoard..cpp

#include <iostream>
#include <string>
#include "printLeaderBoard.h"

using namespace std;

// string name[], string avatar_1[], string boss_stage[], string time[]
int print_board() {
    cout << "-leaderboard-" << endl;
    cout << "Name  Avatar Boss stage Time" << endl;
    return 0;
}