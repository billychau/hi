// "boss.cpp"

#include <iostream>
#include <string>
#include "boss.h"

using namespace std;

bool boss(std::string avatar, int &boss_stage) {
    return false;
}