// printLeaderBoard.h

#ifndef PRINTLEADERBOARD
#define PRINTLEADERBOARD

int print_board();

#endif